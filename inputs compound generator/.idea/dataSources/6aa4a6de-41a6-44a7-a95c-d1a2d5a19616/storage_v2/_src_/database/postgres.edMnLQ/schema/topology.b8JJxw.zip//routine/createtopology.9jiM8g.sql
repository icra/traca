create function createtopology(toponame character varying, srid integer, prec double precision) returns integer
    strict
    language sql
as
$$
SELECT topology.CreateTopology($1, $2, $3, false);
$$;

alter function createtopology(varchar, integer, double precision) owner to postgres;

