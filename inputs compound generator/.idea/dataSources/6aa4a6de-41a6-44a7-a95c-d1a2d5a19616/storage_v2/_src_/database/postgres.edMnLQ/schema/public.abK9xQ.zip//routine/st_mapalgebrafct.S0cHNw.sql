create function st_mapalgebrafct(rast raster, band integer, onerastuserfunc regprocedure, VARIADIC args text[]) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_mapalgebrafct($1, $2, NULL, $3, VARIADIC $4)
$$;

comment on function st_mapalgebrafct(raster, integer, regprocedure, text[]) is 'args: rast, band, onerasteruserfunc, VARIADIC args - 1 band version - Creates a new one band raster formed by applying a valid PostgreSQL function on the input raster band and of pixeltype prodived. Band 1 is assumed if no band is specified.';

alter function st_mapalgebrafct(raster, integer, regprocedure, text[]) owner to postgres;

