create function st_distinct4ma(matrix double precision[], nodatamode text, VARIADIC args text[]) returns double precision
    immutable
    parallel safe
    language sql
as
$$
SELECT COUNT(DISTINCT unnest)::float FROM unnest($1)
$$;

comment on function st_distinct4ma(double precision[], text, text[]) is 'args: matrix, nodatamode, VARIADIC args - Raster processing function that calculates the number of unique pixel values in a neighborhood.';

alter function st_distinct4ma(double precision[], text, text[]) owner to postgres;

