create function asgml(tg topology.topogeometry, nsprefix text, prec integer, opts integer) returns text
    stable
    language sql
as
$$
SELECT topology.AsGML($1, $2, $3, $4, NULL);
$$;

alter function asgml(topology.topogeometry, text, integer, integer) owner to postgres;

