create function asgml(tg topology.topogeometry, visitedtable regclass, nsprefix text) returns text
    language sql
as
$$
SELECT topology.AsGML($1, $3, 15, 1, $2);
$$;

alter function asgml(topology.topogeometry, regclass, text) owner to postgres;

