create function st_pixelofvalue(rast raster, nband integer, search double precision, exclude_nodata_value boolean DEFAULT true, OUT x integer, OUT y integer) returns SETOF record
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT x, y FROM public.ST_PixelofValue($1, $2, ARRAY[$3], $4)
$$;

comment on function st_pixelofvalue(raster, integer, double precision, boolean, out integer, out integer) is 'args: rast, nband, search, exclude_nodata_value=true - Get the columnx, rowy coordinates of the pixel whose value equals the search value.';

alter function st_pixelofvalue(raster, integer, double precision, boolean, out integer, out integer) owner to postgres;

