create function raster_contained_by_geometry(raster, geometry) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$
select $1::public.geometry OPERATOR(public.@) $2
$$;

alter function raster_contained_by_geometry(raster, geometry) owner to postgres;

