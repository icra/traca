create function postgis_topology_scripts_installed() returns text
    immutable
    language sql
as
$$
SELECT trim('3.1.1'::text || $rev$ aaf4c79 $rev$) AS version
$$;

alter function postgis_topology_scripts_installed() owner to postgres;

