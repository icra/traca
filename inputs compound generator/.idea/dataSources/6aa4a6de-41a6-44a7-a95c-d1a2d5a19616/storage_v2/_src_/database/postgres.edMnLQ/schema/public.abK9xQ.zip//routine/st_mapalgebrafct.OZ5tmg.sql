create function st_mapalgebrafct(rast raster, onerastuserfunc regprocedure, VARIADIC args text[]) returns raster
    immutable
    parallel safe
    language sql
as
$$
SELECT public.ST_mapalgebrafct($1, 1, NULL, $2, VARIADIC $3)
$$;

comment on function st_mapalgebrafct(raster, regprocedure, text[]) is 'args: rast, onerasteruserfunc, VARIADIC args - 1 band version - Creates a new one band raster formed by applying a valid PostgreSQL function on the input raster band and of pixeltype prodived. Band 1 is assumed if no band is specified.';

alter function st_mapalgebrafct(raster, regprocedure, text[]) owner to postgres;

