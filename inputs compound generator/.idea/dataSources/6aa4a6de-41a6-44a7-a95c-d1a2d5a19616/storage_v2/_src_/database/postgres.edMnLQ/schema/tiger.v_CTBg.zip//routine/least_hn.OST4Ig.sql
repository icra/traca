create function least_hn(fromhn character varying, tohn character varying) returns integer
    immutable
    cost 200
    language sql
as
$$
SELECT least(to_number( CASE WHEN trim($1) ~ '^[0-9]+$' THEN $1 ELSE '0' END,'9999999'),to_number(CASE WHEN trim($2) ~ '^[0-9]+$' THEN $2 ELSE '0' END,'9999999') )::integer;
$$;

alter function least_hn(varchar, varchar) owner to postgres;

