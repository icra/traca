create function gettopologyname(topoid integer) returns character varying
    stable
    strict
    language plpgsql
as
$$
DECLARE
  ret varchar;
BEGIN
        SELECT name FROM topology.topology into ret
                WHERE id = topoid;
  RETURN ret;
END
$$;

alter function gettopologyname(integer) owner to postgres;

