create function gettopologyid(toponame character varying) returns integer
    stable
    strict
    language plpgsql
as
$$
DECLARE
  ret integer;
BEGIN
  SELECT id INTO ret
    FROM topology.topology WHERE name = toponame;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Topology % does not exist', quote_literal(toponame);
  END IF;

  RETURN ret;
END
$$;

alter function gettopologyid(varchar) owner to postgres;

