create function st_isvalid(geometry, integer) returns boolean
    immutable
    strict
    parallel safe
    cost 10000
    language sql
as
$$
SELECT (public.ST_isValidDetail($1, $2)).valid
$$;

comment on function st_isvalid(geometry, integer) is 'args: g, flags - Tests if a geometry is well-formed in 2D.';

alter function st_isvalid(geometry, integer) owner to postgres;

