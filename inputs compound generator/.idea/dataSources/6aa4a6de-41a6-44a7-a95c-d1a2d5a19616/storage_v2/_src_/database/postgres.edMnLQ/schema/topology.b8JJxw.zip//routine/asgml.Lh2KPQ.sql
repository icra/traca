create function asgml(tg topology.topogeometry) returns text
    stable
    language sql
as
$$
SELECT topology.AsGML($1, 'gml');
$$;

alter function asgml(topology.topogeometry) owner to postgres;

