create function createtopology(character varying, integer) returns integer
    strict
    language sql
as
$$
SELECT topology.CreateTopology($1, $2, 0);
$$;

alter function createtopology(varchar, integer) owner to postgres;

