create function createtopology(character varying) returns integer
    strict
    language sql
as
$$
SELECT topology.CreateTopology($1, ST_SRID('POINT EMPTY'::geometry), 0);
$$;

alter function createtopology(varchar) owner to postgres;

