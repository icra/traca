create function st_reclass(rast raster, reclassexpr text, pixeltype text) returns raster
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT st_reclass($1, ROW(1, $2, $3, NULL))
$$;

comment on function st_reclass(raster, text, text) is 'args: rast, reclassexpr, pixeltype - Creates a new raster composed of band types reclassified from original. The nband is the band to be changed. If nband is not specified assumed to be 1. All other bands are returned unchanged. Use case: convert a 16BUI band to a 8BUI and so forth for simpler rendering as viewable formats.';

alter function st_reclass(raster, text, text) owner to postgres;

