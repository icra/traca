create view act_cabal_anual_1("activitat/ubicacio", cabal_adiari) as
SELECT "cens_v3.3"."activitat/ubicacio",
       avg("cens_v3.3".valor_maxim::double precision) / 365::double precision AS cabal_adiari
FROM "cens_v3.3"
WHERE "cens_v3.3"."data fi vigencia (ca)"::date >= '2020-01-01'::date
  AND "cens_v3.3"."data fi vigencia (ca)"::date <= '2200-01-01'::date
  AND NOT "cens_v3.3"."activitat/ubicacio"::text ~~ '%EDAR%'::text
  AND "cens_v3.3".nom_variable::text = 'Cabal anual'::text
GROUP BY "cens_v3.3"."activitat/ubicacio";

alter table act_cabal_anual_1
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on act_cabal_anual_1 to postgres with grant option;

