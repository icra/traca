create view me_0710
            (codi_aca, variable, media0710, sobre_mitjana0710, incompliment_mitjana0710, maxim0710, sobre_maxim0710,
             incompliment_maxim0710)
as
SELECT me_cppwd_proteccion.codi_aca,
       me_cppwd_proteccion.variable,
       avg(me_cppwd_proteccion.valor)                                            AS media0710,
       avg(me_cppwd_proteccion.valor) - me_cppwd_proteccion.llindar_mitjaanual   AS sobre_mitjana0710,
       count(me_cppwd_proteccion.valor > me_cppwd_proteccion.llindar_mitjaanual) AS incompliment_mitjana0710,
       max(me_cppwd_proteccion.valor)                                            AS maxim0710,
       max(me_cppwd_proteccion.valor) - me_cppwd_proteccion.llindar_mitjaanual   AS sobre_maxim0710,
       count(me_cppwd_proteccion.valor > me_cppwd_proteccion.llindar_maxim)      AS incompliment_maxim0710
FROM me_cppwd_proteccion
WHERE me_cppwd_proteccion.fecha::text >= '2007/01/01'::text
  AND me_cppwd_proteccion.fecha::text <= '2010/12/31'::text
GROUP BY me_cppwd_proteccion.codi_aca, me_cppwd_proteccion.variable, me_cppwd_proteccion.llindar_mitjaanual,
         me_cppwd_proteccion.llindar_maxim
ORDER BY me_cppwd_proteccion.codi_aca, me_cppwd_proteccion.variable;

alter table me_0710
    owner to traca_user;

