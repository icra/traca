create view uwwtp_act(id_0, geom, "activitat/ubicacio", "uwwCode") as
SELECT act_uwwtp.id_0,
       act_uwwtp.geom,
       act_uwwtp."activitat/ubicacio",
       act_uwwtp."uwwCode"
FROM act_uwwtp;

alter table uwwtp_act
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on uwwtp_act to postgres with grant option;

