create view industry_to_edar
            ("activitat/ubicacio", "uwwCode", amoni, dbo5, fosfats, toc, fosfor, nitrats, nitrogen_org, c_d) as
SELECT "cens_v3.3"."activitat/ubicacio",
       uwwtp_act."uwwCode",
       "cens_v3.3".amoni,
       "cens_v3.3".dbo5,
       "cens_v3.3".fosfats,
       "cens_v3.3".toc,
       "cens_v3.3".fosfor,
       "cens_v3.3".nitrats,
       "cens_v3.3".nitrogen_org,
       CASE
           WHEN acd.cabal_diari IS NULL OR acd.cabal_diari = 0::double precision THEN aca.cabal_adiari
           WHEN aca.cabal_adiari IS NULL OR aca.cabal_adiari = 0::double precision THEN acd.cabal_diari
           ELSE acd.cabal_diari
           END AS c_d
FROM "cens_v3.3"
         LEFT JOIN act_cabal_diari_1 acd ON "cens_v3.3"."activitat/ubicacio"::text = acd."activitat/ubicacio"::text
         LEFT JOIN act_cabal_anual_1 aca ON "cens_v3.3"."activitat/ubicacio"::text = aca."activitat/ubicacio"::text,
     uwwtp_act
WHERE (acd.cabal_diari IS NOT NULL OR aca.cabal_adiari IS NOT NULL)
  AND uwwtp_act."activitat/ubicacio"::text = "cens_v3.3"."activitat/ubicacio"::text
GROUP BY "cens_v3.3"."activitat/ubicacio", uwwtp_act."uwwCode", "cens_v3.3".amoni, "cens_v3.3".dbo5,
         "cens_v3.3".fosfats, "cens_v3.3".toc, "cens_v3.3".fosfor, "cens_v3.3".nitrats, "cens_v3.3".nitrogen_org,
         (
             CASE
                 WHEN acd.cabal_diari IS NULL OR acd.cabal_diari = 0::double precision THEN aca.cabal_adiari
                 WHEN aca.cabal_adiari IS NULL OR aca.cabal_adiari = 0::double precision THEN acd.cabal_diari
                 ELSE acd.cabal_diari
                 END);

alter table industry_to_edar
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on industry_to_edar to postgres with grant option;

