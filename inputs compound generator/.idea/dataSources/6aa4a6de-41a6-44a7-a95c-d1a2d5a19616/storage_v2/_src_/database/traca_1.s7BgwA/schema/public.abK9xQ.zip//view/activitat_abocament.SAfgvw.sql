create view activitat_abocament("activitat/ubicacio", nom_abocament, x, y, geom) as
SELECT cens_v3_full."activitat/ubicacio",
       cens_v3_full.nom_abocament,
       cens_v3_full.x,
       cens_v3_full.y,
       cens_v3_full.geom
FROM cens_v3_full
GROUP BY cens_v3_full."activitat/ubicacio", cens_v3_full.nom_abocament, cens_v3_full.x, cens_v3_full.y,
         cens_v3_full.geom;

alter table activitat_abocament
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on activitat_abocament to postgres with grant option;

