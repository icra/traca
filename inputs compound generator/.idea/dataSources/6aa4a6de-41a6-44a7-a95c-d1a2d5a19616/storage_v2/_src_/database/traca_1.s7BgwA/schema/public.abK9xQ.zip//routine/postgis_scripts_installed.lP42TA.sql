create function postgis_scripts_installed() returns text
    immutable
    language sql
as
$$
SELECT trim('3.1.1'::text || $rev$ aaf4c79 $rev$) AS version
$$;

comment on function postgis_scripts_installed() is 'Returns version of the postgis scripts installed in this database.';

alter function postgis_scripts_installed() owner to postgres;

