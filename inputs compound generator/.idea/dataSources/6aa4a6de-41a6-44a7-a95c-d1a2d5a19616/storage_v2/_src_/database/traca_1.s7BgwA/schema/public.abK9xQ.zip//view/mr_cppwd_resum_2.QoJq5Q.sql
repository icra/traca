create view mr_cppwd_resum_2
            (codi_aca, variable, llindar_mitjaanual, media0710, sobre_mitjana0710, incompliment_mitjana0710, maxim0710,
             sobre_maxim0710, incompliment_maxim0710, media1115, sobre_mitjana1115, incompliment_mitjana1115, maxim1115,
             sobre_maxim1115, incompliment_maxim1115, media1620, sobre_mitjana1620, incompliment_mitjana1620, maxim1620,
             sobre_maxim1620, incompliment_maxim1620, unidad_med)
as
SELECT t.codi_aca,
       t.variable,
       t.llindar_mitjaanual,
       a.media0710,
       a.sobre_mitjana0710,
       a.incompliment_mitjana0710,
       a.maxim0710,
       a.sobre_maxim0710,
       a.incompliment_maxim0710,
       b.media1115,
       b.sobre_mitjana1115,
       b.incompliment_mitjana1115,
       b.maxim1115,
       b.sobre_maxim1115,
       b.incompliment_maxim1115,
       c.media1620,
       c.sobre_mitjana1620,
       c.incompliment_mitjana1620,
       c.maxim1620,
       c.sobre_maxim1620,
       c.incompliment_maxim1620,
       t.unidad_med
FROM mr_cppwd_v3 t
         LEFT JOIN mr_0710 a ON t.codi_aca::text = a.codi_aca::text AND t.variable::text = a.variable::text
         LEFT JOIN mr_1115 b ON t.codi_aca::text = b.codi_aca::text AND t.variable::text = b.variable::text
         LEFT JOIN mr_1620 c ON t.codi_aca::text = c.codi_aca::text AND t.variable::text = c.variable::text
GROUP BY t.codi_aca, t.variable, t.llindar_mitjaanual, a.media0710, b.media1115, c.media1620, t.unidad_med,
         a.sobre_mitjana0710, a.incompliment_mitjana0710, a.maxim0710, a.sobre_maxim0710, a.incompliment_maxim0710,
         b.sobre_mitjana1115, b.incompliment_mitjana1115, b.maxim1115, b.sobre_maxim1115, b.incompliment_maxim1115,
         c.sobre_mitjana1620, c.incompliment_mitjana1620, c.maxim1620, c.sobre_maxim1620, c.incompliment_maxim1620
ORDER BY t.codi_aca, t.variable;

alter table mr_cppwd_resum_2
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on mr_cppwd_resum_2 to postgres with grant option;

