create view mr_1620
            (codi_aca, variable, media1620, sobre_mitjana1620, incompliment_mitjana1620, maxim1620, sobre_maxim1620,
             incompliment_maxim1620)
as
SELECT mr_cppwd_proteccion.codi_aca,
       mr_cppwd_proteccion.variable,
       avg(mr_cppwd_proteccion.valor)                                            AS media1620,
       avg(mr_cppwd_proteccion.valor) - mr_cppwd_proteccion.llindar_mitjaanual   AS sobre_mitjana1620,
       count(mr_cppwd_proteccion.valor > mr_cppwd_proteccion.llindar_mitjaanual) AS incompliment_mitjana1620,
       max(mr_cppwd_proteccion.valor)                                            AS maxim1620,
       max(mr_cppwd_proteccion.valor) - mr_cppwd_proteccion.llindar_mitjaanual   AS sobre_maxim1620,
       count(mr_cppwd_proteccion.valor > mr_cppwd_proteccion.llindar_maxim)      AS incompliment_maxim1620
FROM mr_cppwd_proteccion
WHERE mr_cppwd_proteccion.fecha::text >= '2016/01/01'::text
  AND mr_cppwd_proteccion.fecha::text <= '2020/12/31'::text
GROUP BY mr_cppwd_proteccion.codi_aca, mr_cppwd_proteccion.variable, mr_cppwd_proteccion.llindar_mitjaanual,
         mr_cppwd_proteccion.llindar_maxim
ORDER BY mr_cppwd_proteccion.codi_aca, mr_cppwd_proteccion.variable;

alter table mr_1620
    owner to traca_user;

