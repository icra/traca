create view act_cabal_diari_1("activitat/ubicacio", cabal_diari) as
SELECT "cens_v3.3"."activitat/ubicacio",
       avg("cens_v3.3".valor_maxim::double precision) AS cabal_diari
FROM "cens_v3.3"
WHERE "cens_v3.3"."data fi vigencia (ca)"::date >= '2020-01-01'::date
  AND "cens_v3.3"."data fi vigencia (ca)"::date <= '2200-01-01'::date
  AND NOT "cens_v3.3"."activitat/ubicacio"::text ~~ '%EDAR%'::text
  AND "cens_v3.3".nom_variable::text = 'Cabal diari'::text
GROUP BY "cens_v3.3"."activitat/ubicacio";

alter table act_cabal_diari_1
    owner to traca_user;

