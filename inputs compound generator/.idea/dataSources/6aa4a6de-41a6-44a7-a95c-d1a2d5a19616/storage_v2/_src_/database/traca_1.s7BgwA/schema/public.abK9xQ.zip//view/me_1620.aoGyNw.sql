create view me_1620
            (codi_aca, variable, media1620, sobre_mitjana1620, incompliment_mitjana1620, maxim1620, sobre_maxim1620,
             incompliment_maxim1620)
as
SELECT me_cppwd_proteccion.codi_aca,
       me_cppwd_proteccion.variable,
       avg(me_cppwd_proteccion.valor)                                            AS media1620,
       avg(me_cppwd_proteccion.valor) - me_cppwd_proteccion.llindar_mitjaanual   AS sobre_mitjana1620,
       count(me_cppwd_proteccion.valor > me_cppwd_proteccion.llindar_mitjaanual) AS incompliment_mitjana1620,
       max(me_cppwd_proteccion.valor)                                            AS maxim1620,
       max(me_cppwd_proteccion.valor) - me_cppwd_proteccion.llindar_mitjaanual   AS sobre_maxim1620,
       count(me_cppwd_proteccion.valor > me_cppwd_proteccion.llindar_maxim)      AS incompliment_maxim1620
FROM me_cppwd_proteccion
WHERE me_cppwd_proteccion.fecha::text >= '2016/01/01'::text
  AND me_cppwd_proteccion.fecha::text <= '2020/12/31'::text
GROUP BY me_cppwd_proteccion.codi_aca, me_cppwd_proteccion.variable, me_cppwd_proteccion.llindar_mitjaanual,
         me_cppwd_proteccion.llindar_maxim
ORDER BY me_cppwd_proteccion.codi_aca, me_cppwd_proteccion.variable;

alter table me_1620
    owner to traca_user;

