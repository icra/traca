create view load_full_perillosos
            (cod_ccae, "1,2-Dicloroetà", "Antrace", "Benzè", "Cadmi dissolt", "Cloroalcans", "Hexaclorobenzè",
             "Hexaclorobutadiè", "Mercuri dissolt", "Nonilfenols", "Plom dissolt", "Tetracloroetilè", "Tricloroetilè",
             "Triclorometà")
as
SELECT load_full.cod_ccae,
       avg(load_full."1,2-Dicloroetà")   AS "1,2-Dicloroetà",
       avg(load_full."Antrace")          AS "Antrace",
       avg(load_full."Benzè")            AS "Benzè",
       avg(load_full."Cadmi dissolt")    AS "Cadmi dissolt",
       avg(load_full."Cloroalcans")      AS "Cloroalcans",
       avg(load_full."Hexaclorobenzè")   AS "Hexaclorobenzè",
       avg(load_full."Hexaclorobutadiè") AS "Hexaclorobutadiè",
       avg(load_full."Mercuri dissolt")  AS "Mercuri dissolt",
       avg(load_full."Nonilfenols")      AS "Nonilfenols",
       avg(load_full."Plom dissolt")     AS "Plom dissolt",
       avg(load_full."Tetracloroetilè")  AS "Tetracloroetilè",
       avg(load_full."Tricloroetilè")    AS "Tricloroetilè",
       avg(load_full."Triclorometà")     AS "Triclorometà"
FROM load_full
WHERE load_full."1,2-Dicloroetà" IS NOT NULL
   OR load_full."Antrace" IS NOT NULL
   OR load_full."Benzè" IS NOT NULL
   OR load_full."Cadmi dissolt" IS NOT NULL
   OR load_full."Cloroalcans" IS NOT NULL
   OR load_full."Hexaclorobenzè" IS NOT NULL
   OR load_full."Hexaclorobutadiè" IS NOT NULL
   OR load_full."Mercuri dissolt" IS NOT NULL
   OR load_full."Nonilfenols" IS NOT NULL
   OR load_full."Plom dissolt" IS NOT NULL
   OR load_full."Tetracloroetilè" IS NOT NULL
   OR load_full."Tricloroetilè" IS NOT NULL
   OR load_full."Triclorometà" IS NOT NULL
GROUP BY load_full.cod_ccae;

alter table load_full_perillosos
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on load_full_perillosos to postgres with grant option;

