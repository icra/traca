create view variables_cens_fr(nom_variable, cod_ccae) as
SELECT DISTINCT "cens_v3.3".nom_variable,
                "cens_v3.3".cod_ccae
FROM "cens_v3.3"
WHERE "cens_v3.3".tipus IS NOT NULL
UNION
SELECT DISTINCT bd_francesa.variable AS nom_variable,
                bd_francesa.cod_ccae
FROM bd_francesa
WHERE bd_francesa.tipo IS NOT NULL
ORDER BY 1;

alter table variables_cens_fr
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on variables_cens_fr to postgres with grant option;

