create view load_full_perillosos_xs
            (cod_ccae_xs, "1,2-Dicloroetà", "Antrace", "Benzè", "Cadmi dissolt", "Cloroalcans", "Hexaclorobenzè",
             "Hexaclorobutadiè", "Mercuri dissolt", "Nonilfenols", "Plom dissolt", "Tetracloroetilè", "Tricloroetilè",
             "Triclorometà", "Dbo5", "Niquel dissolt")
as
SELECT load_full_xs.cod_ccae_xs,
       avg(load_full_xs."1,2-Dicloroetà")   AS "1,2-Dicloroetà",
       avg(load_full_xs."Antrace")          AS "Antrace",
       avg(load_full_xs."Benzè")            AS "Benzè",
       avg(load_full_xs."Cadmi dissolt")    AS "Cadmi dissolt",
       avg(load_full_xs."Cloroalcans")      AS "Cloroalcans",
       avg(load_full_xs."Hexaclorobenzè")   AS "Hexaclorobenzè",
       avg(load_full_xs."Hexaclorobutadiè") AS "Hexaclorobutadiè",
       avg(load_full_xs."Mercuri dissolt")  AS "Mercuri dissolt",
       avg(load_full_xs."Nonilfenols")      AS "Nonilfenols",
       avg(load_full_xs."Plom dissolt")     AS "Plom dissolt",
       avg(load_full_xs."Tetracloroetilè")  AS "Tetracloroetilè",
       avg(load_full_xs."Tricloroetilè")    AS "Tricloroetilè",
       avg(load_full_xs."Triclorometà")     AS "Triclorometà",
       avg(load_full_xs."Dbo5")             AS "Dbo5",
       avg(load_full_xs."Niquel dissolt")   AS "Niquel dissolt"
FROM load_full_xs
WHERE load_full_xs."Niquel dissolt" IS NOT NULL
   OR load_full_xs."Dbo5" IS NOT NULL
   OR load_full_xs."1,2-Dicloroetà" IS NOT NULL
   OR load_full_xs."Antrace" IS NOT NULL
   OR load_full_xs."Benzè" IS NOT NULL
   OR load_full_xs."Cadmi dissolt" IS NOT NULL
   OR load_full_xs."Cloroalcans" IS NOT NULL
   OR load_full_xs."Hexaclorobenzè" IS NOT NULL
   OR load_full_xs."Hexaclorobutadiè" IS NOT NULL
   OR load_full_xs."Mercuri dissolt" IS NOT NULL
   OR load_full_xs."Nonilfenols" IS NOT NULL
   OR load_full_xs."Plom dissolt" IS NOT NULL
   OR load_full_xs."Tetracloroetilè" IS NOT NULL
   OR load_full_xs."Tricloroetilè" IS NOT NULL
   OR load_full_xs."Triclorometà" IS NOT NULL
GROUP BY load_full_xs.cod_ccae_xs;

alter table load_full_perillosos_xs
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on load_full_perillosos_xs to postgres with grant option;

