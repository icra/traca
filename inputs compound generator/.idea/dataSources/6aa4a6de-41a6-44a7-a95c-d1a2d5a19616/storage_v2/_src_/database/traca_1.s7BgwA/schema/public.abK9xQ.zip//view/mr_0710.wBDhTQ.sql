create view mr_0710
            (codi_aca, variable, media0710, sobre_mitjana0710, incompliment_mitjana0710, maxim0710, sobre_maxim0710,
             incompliment_maxim0710)
as
SELECT mr_cppwd_proteccion.codi_aca,
       mr_cppwd_proteccion.variable,
       avg(mr_cppwd_proteccion.valor)                                            AS media0710,
       avg(mr_cppwd_proteccion.valor) - mr_cppwd_proteccion.llindar_mitjaanual   AS sobre_mitjana0710,
       count(mr_cppwd_proteccion.valor > mr_cppwd_proteccion.llindar_mitjaanual) AS incompliment_mitjana0710,
       max(mr_cppwd_proteccion.valor)                                            AS maxim0710,
       max(mr_cppwd_proteccion.valor) - mr_cppwd_proteccion.llindar_mitjaanual   AS sobre_maxim0710,
       count(mr_cppwd_proteccion.valor > mr_cppwd_proteccion.llindar_maxim)      AS incompliment_maxim0710
FROM mr_cppwd_proteccion
WHERE mr_cppwd_proteccion.fecha::text >= '2007/01/01'::text
  AND mr_cppwd_proteccion.fecha::text <= '2010/12/31'::text
GROUP BY mr_cppwd_proteccion.codi_aca, mr_cppwd_proteccion.variable, mr_cppwd_proteccion.llindar_mitjaanual,
         mr_cppwd_proteccion.llindar_maxim
ORDER BY mr_cppwd_proteccion.codi_aca, mr_cppwd_proteccion.variable;

alter table mr_0710
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on mr_0710 to postgres with grant option;

