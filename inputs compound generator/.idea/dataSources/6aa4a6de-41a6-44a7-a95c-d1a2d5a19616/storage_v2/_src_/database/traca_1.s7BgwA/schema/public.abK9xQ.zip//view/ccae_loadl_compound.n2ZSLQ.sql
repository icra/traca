create view ccae_loadl_compound
            (cod_ccae, "1,1,1-Tricloroetà", "1,2-Dicloroetà", alaclor, antrace, arsenic_dissolt, atracina, benze,
             "Benzo(b)fluorantè", "Benzo(g.h.i)perilè", "Benzo(k)fluorantè", cadmi_dissolt, cianurs_totals,
             clorfenvinfos, cloroalcans, clorobenze, clorpirifos, coure_dissolt, crom_dissolt, crom_vi,
             difelineters_bromats, diuron, etilbenze, fluorante, hexaclorobenze, hexaclorobutadie, hexaclorociclohexa,
             isoproturon, mercuri_dissolt, naftale, nonilfenols, octilfenols, pentaclorobenze, pentaclorofenol,
             plom_dissolt, simazina, tetracloroetile, tetraclorur_carboni, tolue, tricloroetile, trifluralina, xile,
             zinc_dissolt, niquel_dissolt, unitats)
as
SELECT act_ccae_uww_load_v1.cod_ccae,
       sum(act_ccae_uww_load_v1."1,1,1-Tricloroetà")      AS "1,1,1-Tricloroetà",
       sum(act_ccae_uww_load_v1."1,2-Dicloroetà")         AS "1,2-Dicloroetà",
       sum(act_ccae_uww_load_v1."Alaclor")                AS alaclor,
       sum(act_ccae_uww_load_v1."Antracè")                AS antrace,
       sum(act_ccae_uww_load_v1."Arsènic dissolt")        AS arsenic_dissolt,
       sum(act_ccae_uww_load_v1."Atracina")               AS atracina,
       sum(act_ccae_uww_load_v1."Benzè")                  AS benze,
       sum(act_ccae_uww_load_v1."Benzo(b)fluorantè")      AS "Benzo(b)fluorantè",
       sum(act_ccae_uww_load_v1."Benzo(g.h.i)perilè")     AS "Benzo(g.h.i)perilè",
       sum(act_ccae_uww_load_v1."Benzo(k)fluorantè")      AS "Benzo(k)fluorantè",
       sum(act_ccae_uww_load_v1."Cadmi dissolt")          AS cadmi_dissolt,
       sum(act_ccae_uww_load_v1."Cianurs totals")         AS cianurs_totals,
       sum(act_ccae_uww_load_v1."Clorfenvinfos")          AS clorfenvinfos,
       sum(act_ccae_uww_load_v1."Cloroalcans")            AS cloroalcans,
       sum(act_ccae_uww_load_v1."Clorobenzè")             AS clorobenze,
       sum(act_ccae_uww_load_v1."Clorpirifòs")            AS clorpirifos,
       sum(act_ccae_uww_load_v1."Coure dissolt")          AS coure_dissolt,
       sum(act_ccae_uww_load_v1."Crom dissolt")           AS crom_dissolt,
       sum(act_ccae_uww_load_v1."Crom VI")                AS crom_vi,
       sum(act_ccae_uww_load_v1."Difelineters bromats")   AS difelineters_bromats,
       sum(act_ccae_uww_load_v1."Diuron")                 AS diuron,
       sum(act_ccae_uww_load_v1."Etilbenzè")              AS etilbenze,
       sum(act_ccae_uww_load_v1."Fluorantè")              AS fluorante,
       sum(act_ccae_uww_load_v1."Hexaclorobenzè")         AS hexaclorobenze,
       sum(act_ccae_uww_load_v1."Hexaclorobutadiè")       AS hexaclorobutadie,
       sum(act_ccae_uww_load_v1."Hexaclorociclohexà")     AS hexaclorociclohexa,
       sum(act_ccae_uww_load_v1."Isoproturon")            AS isoproturon,
       sum(act_ccae_uww_load_v1."Mercuri dissolt")        AS mercuri_dissolt,
       sum(act_ccae_uww_load_v1."Naftalè")                AS naftale,
       sum(act_ccae_uww_load_v1."Nonilfenols")            AS nonilfenols,
       sum(act_ccae_uww_load_v1."Octilfenols")            AS octilfenols,
       sum(act_ccae_uww_load_v1."Pentaclorobenzè")        AS pentaclorobenze,
       sum(act_ccae_uww_load_v1."Pentaclorofenol")        AS pentaclorofenol,
       sum(act_ccae_uww_load_v1."Plom dissolt")           AS plom_dissolt,
       sum(act_ccae_uww_load_v1."Simazina")               AS simazina,
       sum(act_ccae_uww_load_v1."Tetracloroetilè")        AS tetracloroetile,
       sum(act_ccae_uww_load_v1."Tetraclorur de carboni") AS tetraclorur_carboni,
       sum(act_ccae_uww_load_v1."Toluè")                  AS tolue,
       sum(act_ccae_uww_load_v1."Tricloroetilè")          AS tricloroetile,
       sum(act_ccae_uww_load_v1."Trifluralina")           AS trifluralina,
       sum(act_ccae_uww_load_v1."Xilè")                   AS xile,
       sum(act_ccae_uww_load_v1."Zinc dissolt")           AS zinc_dissolt,
       sum(act_ccae_uww_load_v1."Niquel dissolt")         AS niquel_dissolt,
       act_ccae_uww_load_v1.unitats
FROM act_ccae_uww_load_v1
GROUP BY act_ccae_uww_load_v1.cod_ccae, act_ccae_uww_load_v1.unitats
ORDER BY act_ccae_uww_load_v1.cod_ccae;

alter table ccae_loadl_compound
    owner to traca_user;

grant delete, insert, references, select, trigger, truncate, update on ccae_loadl_compound to postgres with grant option;

