create view me_1115
            (codi_aca, variable, media1115, sobre_mitjana1115, incompliment_mitjana1115, maxim1115, sobre_maxim1115,
             incompliment_maxim1115)
as
SELECT me_cppwd_proteccion.codi_aca,
       me_cppwd_proteccion.variable,
       avg(me_cppwd_proteccion.valor)                                            AS media1115,
       avg(me_cppwd_proteccion.valor) - me_cppwd_proteccion.llindar_mitjaanual   AS sobre_mitjana1115,
       count(me_cppwd_proteccion.valor > me_cppwd_proteccion.llindar_mitjaanual) AS incompliment_mitjana1115,
       max(me_cppwd_proteccion.valor)                                            AS maxim1115,
       max(me_cppwd_proteccion.valor) - me_cppwd_proteccion.llindar_mitjaanual   AS sobre_maxim1115,
       count(me_cppwd_proteccion.valor > me_cppwd_proteccion.llindar_maxim)      AS incompliment_maxim1115
FROM me_cppwd_proteccion
WHERE me_cppwd_proteccion.fecha::text >= '2011/01/01'::text
  AND me_cppwd_proteccion.fecha::text <= '2015/12/31'::text
GROUP BY me_cppwd_proteccion.codi_aca, me_cppwd_proteccion.variable, me_cppwd_proteccion.llindar_mitjaanual,
         me_cppwd_proteccion.llindar_maxim
ORDER BY me_cppwd_proteccion.codi_aca, me_cppwd_proteccion.variable;

alter table me_1115
    owner to traca_user;

